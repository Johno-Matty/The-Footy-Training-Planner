<?php 
include_once 'header.php'
?>

    <div class="text-box">

        <h1>The Footy Training Planner</h1>
        <p>Please login to access the create a drill section
        </p>
        <a href="signup.php" class="hero-btn">Sign Up Today Today To Get Started</a>
        </div>
	</section>
    
    <!-------- course - 38.30 on yt -  ----->


<!------JavaScript for Togle Menu (in mobile mode)-->
<script>
    
    var navLinks = document.getElementById("navLinks");
    
    function showMenu(){
        navLinks.style.right = "0";
    }
    function hideMenu(){
        navLinks.style.right = "-200px";
    }
    
</script>

</body>
</html>